export class Config {
    socketURL = "http://192.168.1.104:3000";
    siteUrl = "http://192.168.1.104:3000";
}