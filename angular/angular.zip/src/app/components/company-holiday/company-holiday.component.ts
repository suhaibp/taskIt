import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-company-holiday',
  templateUrl: './company-holiday.component.html',
  styleUrls: ['./company-holiday.component.css']
})
export class CompanyHolidayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
