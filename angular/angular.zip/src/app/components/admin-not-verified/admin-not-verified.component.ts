import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'admin-not-verified',
  templateUrl: './admin-not-verified.component.html',
  styleUrls: ['./admin-not-verified.component.css']
})
export class AdminNotVerifiedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
