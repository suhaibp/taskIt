import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'admin-expired',
  templateUrl: './admin-expired.component.html',
  styleUrls: ['./admin-expired.component.css']
})
export class AdminExpiredComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
