import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'admin-trial',
  templateUrl: './admin-trial.component.html',
  styleUrls: ['./admin-trial.component.css']
})
export class AdminTrialComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
