import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'admin-subscribed',
  templateUrl: './admin-subscribed.component.html',
  styleUrls: ['./admin-subscribed.component.css']
})
export class AdminSubscribedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
