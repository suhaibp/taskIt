import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'company-sidebar',
  templateUrl: './company-sidebar.component.html',
  styleUrls: ['./company-sidebar.component.css']
})
export class CompanySidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
